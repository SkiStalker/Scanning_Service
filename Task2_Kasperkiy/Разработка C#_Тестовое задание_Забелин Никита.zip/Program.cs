﻿namespace Task2_Kapserskiy
{
    class Program
    {
        static void Main(string[] args)
        {
            ScanServiceNetwork? scanService = null;
            ScanClient scanClient = new ScanClient();
            Thread? serviceThread = null;
            bool alive = true;
            while (alive)
            {
                string? buf = Console.ReadLine();
                if (buf == null)
                {
                    continue;
                }
                string[] parts = buf.Split(' ');
                if (parts.Length == 0)
                {
                    continue;
                }
                switch (parts[0])
                {
                    case "scan_service":
                        {
                            if (scanService == null)
                            {
                                scanService = new ScanServiceNetwork();
                                serviceThread = new Thread(scanService.Start);
                                serviceThread.Start();
                                Console.WriteLine("Scan service started");
                            }
                            else
                            {
                                Console.WriteLine("Scan server already started");
                            }
                            break;
                        }
                    case "scan_util":
                        {
                            if (scanService == null)
                            {
                                Console.WriteLine("Scan service is not active");
                            }
                            else
                            {
                                if (parts.Length != 3)
                                {
                                    Console.WriteLine("Wrong input");
                                }
                                else
                                {
                                    switch (parts[1])
                                    {
                                        case "scan":
                                            {
                                                ScanDto? dto = scanClient.Scan(parts[2]);
                                                Console.Write(dto?.ToString());
                                                break;
                                            }
                                        case "status":
                                            {
                                                ScanDto? dto = scanClient.Status(parts[2]);
                                                if (dto != null)
                                                {
                                                    if (dto.Errors != null)
                                                    {
                                                        Console.WriteLine("====== Scan result ======");
                                                        Console.Write(dto);
                                                        Console.WriteLine("=========================");
                                                    }
                                                    else
                                                    {
                                                        Console.Write(dto);
                                                    }
                                                }
                                                break;
                                            }
                                        default:
                                            {
                                                Console.WriteLine("Incorrect command");
                                                break;
                                            }
                                    }
                                }
                            }
                            break;
                        }
                    case "exit":
                        {
                            alive = false;
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Incorrect command");
                            break;
                        }
                }
                Console.WriteLine();
            }
            scanService?.Stop();
            scanService = null;
        }
    }
}